I, the copyright holder of this work, hereby release it into the public domain. This applies worldwide.

In case this is not legally possible, I grant any entity the right to use, modify and redistribute this work for any purpose, without any conditions.
